const categoriesObj = [
    {
        "id": "all",
        "name": "all"
    },
    {
        "id": "dresses",
        "name": "dresses"
    },
    {
        "id": "blouses",
        "name": "blouses"
    },
    {
        "id": "jeans",
        "name": "jeans"
    },
    {
        "id": "shoes",
        "name": "shoes"
    }
];



export { categoriesObj };